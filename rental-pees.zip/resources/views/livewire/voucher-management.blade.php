<div class="min-h-screen bg-base-200 p-4 md:p-6">
    <!-- Header dengan gradient -->
    <div class="mb-8 relative overflow-hidden rounded-3xl bg-gradient-to-r from-primary via-accent to-secondary p-8 shadow-2xl">
        <div class="absolute inset-0 bg-black/10"></div>
        <div class="relative z-10">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold text-white mb-2 flex items-center gap-3">
                        <i class='bx bxs-coupon text-5xl'></i>
                        Voucher Management
                    </h1>
                    <p class="text-white/90 text-lg">Kelola voucher member dengan mudah</p>
                </div>
                <button wire:click="openModal" class="btn btn-lg gap-2 bg-white text-primary hover:bg-base-100 border-0 shadow-xl px-8">
                    <i class='bx bx-plus-circle text-xl'></i>
                    <span class="font-bold">Buat Voucher</span>
                </button>
            </div>
        </div>
        <div class="absolute -bottom-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
        <div class="absolute -top-10 -left-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
    </div>

    <!-- Filter Section -->
    <div class="card bg-base-100 shadow-xl mb-6 border border-base-200">
        <div class="card-body space-y-6">
            <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                    <p class="text-sm text-base-content/70">Persempit pencarian voucher berdasarkan status & kata kunci</p>
                    <h3 class="card-title text-2xl">
                        <i class='bx bx-filter text-primary'></i>
                        Kontrol Filter Pintar
                    </h3>
                </div>
                <button wire:click="resetFilters" type="button" class="btn btn-ghost gap-2 px-6">
                    <i class='bx bx-refresh text-xl'></i>
                    <span class="font-semibold">Reset Semua</span>
                </button>
            </div>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="rounded-2xl border border-primary/30 bg-primary/5 p-4">
                    <p class="text-xs uppercase text-primary/80 font-semibold">Total Voucher</p>
                    <p class="text-3xl font-bold text-primary">{{ $filterSummary['total'] ?? 0 }}</p>
                </div>
                <div class="rounded-2xl border border-success/30 bg-success/5 p-4">
                    <p class="text-xs uppercase text-success/80 font-semibold">Aktif</p>
                    <div class="flex items-end justify-between">
                        <p class="text-3xl font-bold text-success">{{ $filterSummary['active'] ?? 0 }}</p>
                        <span class="badge badge-success badge-outline">READY</span>
                    </div>
                </div>
                <div class="rounded-2xl border border-warning/30 bg-warning/5 p-4">
                    <p class="text-xs uppercase text-warning/80 font-semibold">Pending QRIS</p>
                    <div class="flex items-end justify-between">
                        <p class="text-3xl font-bold text-warning">{{ $filterSummary['pending'] ?? 0 }}</p>
                        <span class="text-xs text-warning/80">Perlu aksi</span>
                    </div>
                </div>
                <div class="rounded-2xl border border-secondary/30 bg-secondary/5 p-4">
                    <p class="text-xs uppercase text-secondary/80 font-semibold">Omzet Hari Ini</p>
                    <p class="text-2xl font-bold text-secondary">
                        Rp {{ number_format($filterSummary['todayRevenue'] ?? 0, 0, ',', '.') }}
                    </p>
                </div>
            </div>

            @php
                $quickFilters = [
                    '' => ['label' => 'Semua', 'icon' => 'bx bx-layer', 'hint' => $filterSummary['total'] ?? 0],
                    'aktif' => ['label' => 'Aktif', 'icon' => 'bx bx-bolt-circle', 'hint' => $filterSummary['active'] ?? 0],
                    'terpakai' => ['label' => 'Terpakai', 'icon' => 'bx bx-check-shield', 'hint' => $filterSummary['used'] ?? 0],
                    'expired' => ['label' => 'Expired', 'icon' => 'bx bx-calendar-x', 'hint' => $filterSummary['expired'] ?? 0],
                    'pending' => ['label' => 'Pending QRIS', 'icon' => 'bx bx-time-five', 'hint' => $filterSummary['pending'] ?? 0],
                ];
            @endphp

            <div class="flex flex-wrap gap-2">
                @foreach($quickFilters as $value => $filter)
                    @php $isActiveFilter = $statusFilter === $value; @endphp
                    <button
                        type="button"
                        wire:click="$set('statusFilter', '{{ $value }}')"
                        class="btn btn-sm md:btn-md rounded-full border transition-all duration-200 {{ $isActiveFilter
                            ? 'bg-primary text-white border-primary shadow-lg shadow-primary/30'
                            : 'bg-base-200 border-base-300 text-base-content/80 hover:bg-base-300' }}">
                        <i class="{{ $filter['icon'] }} text-lg"></i>
                        <span class="font-semibold">{{ $filter['label'] }}</span>
                        <span class="badge badge-sm badge-ghost">{{ $filter['hint'] }}</span>
                    </button>
                @endforeach
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-4 gap-4">
                <div class="lg:col-span-2">
                    <label class="label">
                        <span class="label-text font-semibold">Cari Voucher / Pembeli</span>
                    </label>
                    <div class="relative">
                        <input type="text" wire:model.live="search" placeholder="Ketik kode, nama member, atau nama pembeli" 
                               class="input input-bordered w-full pl-12">
                        <i class='bx bx-search absolute left-3 top-1/2 -translate-y-1/2 text-2xl text-base-content/50'></i>
                    </div>
                </div>
                <div>
                    <label class="label">
                        <span class="label-text font-semibold">Status Detail</span>
                    </label>
                    <select wire:model.live="statusFilter" class="select select-bordered w-full">
                        <option value="">Semua Status</option>
                        <option value="aktif">Aktif</option>
                        <option value="terpakai">Terpakai</option>
                        <option value="expired">Expired</option>
                        <option value="pending">Pending QRIS</option>
                    </select>
                </div>
                <div>
                    <label class="label">
                        <span class="label-text font-semibold">Tombol Cepat</span>
                    </label>
                    <div class="flex gap-2">
                        <button type="button" wire:click="resetFilters" class="btn btn-outline w-full">
                            Bersihkan
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Vouchers Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @forelse ($vouchers as $voucher)
            @php
                $cardBorderClass = match ($voucher->status) {
                    'aktif' => 'border-success',
                    'terpakai' => 'border-info',
                    default => 'border-error',
                };

                $statusBadgeClass = match ($voucher->status) {
                    'aktif' => 'badge-success',
                    'terpakai' => 'badge-info',
                    default => 'badge-error',
                };
            @endphp
            <div class="card bg-base-100 shadow-xl hover:shadow-2xl transform hover:-translate-y-1 transition-all duration-300 border-2 {{ $cardBorderClass }}">
                
                <div class="card-body">
                    <!-- Status Badge -->
                    <div class="flex flex-wrap justify-between items-start gap-2 mb-3">
                        <div class="flex flex-wrap gap-2">
                            <div class="badge badge-lg gap-2 {{ $statusBadgeClass }}">
                                <i class='bx bxs-circle text-xs'></i>
                                <span class="whitespace-nowrap">{{ strtoupper($voucher->status) }}</span>
                            </div>
                            @if(isset($voucher->status_pembayaran) && $voucher->status_pembayaran === 'pending')
                                <div class="badge badge-lg badge-warning gap-2">
                                    <i class='bx bx-time-five text-xs'></i>
                                    <span class="whitespace-nowrap text-xs sm:text-sm">PENDING</span>
                                </div>
                            @endif
                            @if($voucher->metode_pembayaran === 'kompromi')
                                <div class="badge badge-lg badge-info gap-2">
                                    <i class='bx bx-handshake text-xs'></i>
                                    <span class="whitespace-nowrap text-xs sm:text-sm">KOMPROMI</span>
                                </div>
                            @endif
                        </div>
                        @if($voucher->status === 'aktif')
                            <button wire:click="confirmDelete({{ $voucher->id }})"
                                    class="btn btn-circle btn-sm btn-error btn-ghost">
                                <i class='bx bx-trash'></i>
                            </button>
                        @endif
                    </div>

                    <!-- Kode Voucher -->
                    <div class="bg-gradient-to-r from-primary to-accent rounded-xl p-4 mb-4 text-center">
                        <p class="text-white/70 text-xs mb-1">KODE VOUCHER</p>
                        <p class="text-white font-mono text-xl font-bold tracking-wider">{{ $voucher->kode_voucher }}</p>
                    </div>

                    <!-- Detail -->
                    <div class="space-y-3">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                                <i class='bx bx-user text-primary text-xl'></i>
                            </div>
                            <div class="min-w-0 flex-1">
                                @if($voucher->member_id)
                                    <p class="text-xs text-base-content/60">Member</p>
                                    <p class="font-semibold truncate">{{ $voucher->member->name }}</p>
                                @else
                                    <p class="text-xs text-base-content/60">Pembeli</p>
                                    <p class="font-semibold truncate">{{ $voucher->nama_pembeli }}</p>
                                    <span class="badge badge-sm badge-ghost mt-1">Non-Member</span>
                                @endif
                            </div>
                        </div>

                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center flex-shrink-0">
                                <i class='bx bx-time text-secondary text-xl'></i>
                            </div>
                            <div>
                                <p class="text-xs text-base-content/60">Durasi</p>
                                @if($voucher->metode_pembayaran === 'kompromi' && $voucher->durasi_menit)
                                    <p class="font-semibold">{{ $voucher->durasi_menit }} Menit</p>
                                    <p class="text-xs text-base-content/50">(≈ {{ $voucher->durasi_jam }} jam)</p>
                                @else
                                    <p class="font-semibold">{{ $voucher->durasi_jam }} Jam</p>
                                @endif
                            </div>
                        </div>

                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-success/10 flex items-center justify-center flex-shrink-0">
                                <i class='bx bx-money text-success text-xl'></i>
                            </div>
                            <div>
                                <p class="text-xs text-base-content/60">Total Harga</p>
                                <p class="font-bold text-success text-lg">
                                    Rp {{ number_format($voucher->total_harga, 0, ',', '.') }}
                                </p>
                                <p class="text-xs text-base-content/50">Rp {{ number_format($voucher->harga_per_jam, 0, ',', '.') }}/jam × {{ $voucher->durasi_jam }} jam</p>
                            </div>
                        </div>

                        @if($voucher->metode_pembayaran === 'qris')
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full bg-warning/10 flex items-center justify-center flex-shrink-0">
                                    <i class='bx bx-qr text-warning text-xl'></i>
                                </div>
                                <div>
                                    <p class="text-xs text-base-content/60">Nominal QRIS Unik</p>
                                    <p class="font-bold text-warning text-lg">
                                        @if($voucher->qris_nominal)
                                            Rp {{ number_format($voucher->qris_nominal, 0, ',', '.') }}
                                        @else
                                            <span class="text-error">Belum tersedia</span>
                                        @endif
                                    </p>
                                    <p class="text-xs text-base-content/50">Termasuk kode unik validasi transfer</p>
                                </div>
                            </div>
                        @endif

                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0">
                                <i class='bx bx-purchase-tag text-accent text-xl'></i>
                            </div>
                            <div class="min-w-0 flex-1">
                                <p class="text-xs text-base-content/60">Tarif</p>
                                <p class="font-semibold truncate">
                                    @if($voucher->tarif)
                                        {{ $voucher->tarif->tipe_ps }} - {{ $voucher->tarif->jenis_tarif ?? 'Tarif Standard' }}
                                    @elseif($voucher->harga_per_jam > 0)
                                        <span class="text-warning">Rp {{ number_format($voucher->harga_per_jam, 0, ',', '.') }}/jam</span>
                                    @else
                                        <span class="text-error">Tarif tidak tersedia</span>
                                    @endif
                                </p>
                            </div>
                        </div>
                        
                        <div class="divider my-2"></div>

                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-info/10 flex items-center justify-center flex-shrink-0">
                                <i class='bx bx-calendar text-info text-xl'></i>
                            </div>
                            <div class="flex-1">
                                <p class="text-xs text-base-content/60">Tanggal Beli</p>
                                <p class="font-semibold text-sm">{{ $voucher->tanggal_beli->format('d M Y H:i') }}</p>
                            </div>
                        </div>

                        @if($voucher->status === 'terpakai')
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full bg-success/10 flex items-center justify-center">
                                    <i class='bx bx-check-circle text-success text-xl'></i>
                                </div>
                                <div class="flex-1">
                                    <p class="text-xs text-base-content/60">Dipakai Pada</p>
                                    <p class="font-semibold text-sm">{{ $voucher->tanggal_pakai->format('d M Y H:i') }}</p>
                                </div>
                            </div>
                        @else
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full bg-warning/10 flex items-center justify-center">
                                    <i class='bx bx-calendar-x text-warning text-xl'></i>
                                </div>
                                <div class="flex-1">
                                    <p class="text-xs text-base-content/60">Expired</p>
                                    <p class="font-semibold text-sm">{{ $voucher->expired_at->format('d M Y') }}</p>
                                </div>
                            </div>
                        @endif

                        <!-- Tombol Approve/Reject untuk QRIS Pending -->
                        @if(isset($voucher->status_pembayaran) && $voucher->status_pembayaran === 'pending')
                            <div class="divider my-2"></div>
                            <div class="alert alert-warning text-sm py-2">
                                <i class='bx bx-info-circle'></i>
                                <span class="text-xs">Menunggu konfirmasi pembayaran</span>
                            </div>
                            
                            @if($voucher->metode_pembayaran === 'qris')
                                <div class="mt-3">
                                    <button wire:click="showQris({{ $voucher->id }})"
                                            class="btn btn-info btn-sm md:btn-md w-full gap-2 text-base-content">
                                        <i class='bx bx-qr text-lg'></i>
                                        <span class="font-semibold">Preview QRIS</span>
                                    </button>
                                </div>
                            @endif

                            @if($voucher->qris_image)
                                <div class="mt-3">
                                    <p class="text-xs text-base-content/60 mb-2">Bukti Pembayaran:</p>
                                    <div class="relative group cursor-pointer" wire:click="showImage('{{ $voucher->qris_image }}')">
                                        <img src="{{ asset('storage/' . $voucher->qris_image) }}" 
                                             alt="Bukti Pembayaran" 
                                             class="w-full h-32 object-cover rounded-lg border-2 border-base-300 hover:border-primary transition-all">
                                        <div class="absolute inset-0 bg-black/0 group-hover:bg-black/50 rounded-lg transition-all flex items-center justify-center">
                                            <i class='bx bx-search-alt text-4xl text-white opacity-0 group-hover:opacity-100 transition-all'></i>
                                        </div>
                                    </div>
                                </div>
                            @else
                                <div class="mt-3">
                                    <div class="alert alert-info text-xs py-2">
                                        <i class='bx bx-info-circle'></i>
                                        <span>Belum ada bukti pembayaran (Cash)</span>
                                    </div>
                                </div>
                            @endif
                            
                            <div class="flex gap-2 mt-3">
                                <button wire:click="confirmApprove({{ $voucher->id }})"
                                        class="btn btn-success btn-sm md:btn-md flex-1 gap-2">
                                    <i class='bx bx-check text-lg'></i>
                                    <span class="font-semibold">Approve</span>
                                </button>
                                <button wire:click="confirmReject({{ $voucher->id }})"
                                        class="btn btn-error btn-sm md:btn-md flex-1 gap-2">
                                    <i class='bx bx-x text-lg'></i>
                                    <span class="font-semibold">Tolak</span>
                                </button>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        @empty
            <div class="col-span-full">
                <div class="card bg-base-100 shadow-xl">
                    <div class="card-body items-center text-center py-16">
                        <i class='bx bx-coupon text-8xl text-base-content/20'></i>
                        <h3 class="text-2xl font-bold mt-4">Belum Ada Voucher</h3>
                        <p class="text-base-content/60">Klik tombol "Buat Voucher" untuk membuat voucher baru</p>
                    </div>
                </div>
            </div>
        @endforelse
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        {{ $vouchers->links() }}
    </div>

    <!-- Modal Buat Voucher -->
    @if($isOpen)
        <div class="modal modal-open">
            <div class="modal-box max-w-2xl bg-gradient-to-br from-base-100 to-base-200">
                <h3 class="font-bold text-3xl mb-6 flex items-center gap-3">
                    <div class="w-12 h-12 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center">
                        <i class='bx bx-plus text-white text-2xl'></i>
                    </div>
                    Buat Voucher Baru
                </h3>
                
                <form wire:submit.prevent="store">
                    <div class="space-y-4">
                        <!-- Pilihan: Member atau Custom Name -->
                        <div class="alert alert-info">
                            <i class='bx bx-info-circle text-xl'></i>
                            <span>Pilih member yang terdaftar ATAU isi nama pembeli manual</span>
                        </div>

                        <div class="form-control">
                            <label class="label">
                                <span class="label-text font-semibold">Pilih Member (Opsional)</span>
                            </label>
                            <select wire:model.live="member_id" class="select select-bordered w-full">
                                <option value="">-- Pilih Member (atau isi nama di bawah) --</option>
                                @foreach($members as $member)
                                    <option value="{{ $member->id }}">{{ $member->name }} ({{ $member->email }})</option>
                                @endforeach
                            </select>
                            @error('member_id') <span class="text-error text-sm">{{ $message }}</span> @enderror
                        </div>

                        <div class="divider">ATAU</div>

                        <div class="form-control">
                            <label class="label">
                                <span class="label-text font-semibold">Nama Pembeli (Jika tidak ada member)</span>
                            </label>
                            <input type="text" wire:model.live="nama_pembeli" 
                                   class="input input-bordered w-full" 
                                   placeholder="Contoh: Karyawan A, Pelanggan Walk-in, dll"
                                   @if($member_id) disabled @endif>
                            @error('nama_pembeli') <span class="text-error text-sm">{{ $message }}</span> @enderror
                            @if($member_id)
                                <label class="label">
                                    <span class="label-text-alt text-warning">Member dipilih, nama custom dinonaktifkan</span>
                                </label>
                            @endif
                        </div>

                        <div class="form-control">
                            <label class="label">
                                <span class="label-text font-semibold">Metode Pembayaran</span>
                            </label>
                            <div class="grid grid-cols-2 gap-3">
                                <label class="label cursor-pointer border-2 rounded-lg p-4 has-[:checked]:border-success has-[:checked]:bg-success/10">
                                    <div class="flex flex-col items-center gap-2 flex-1">
                                        <i class='bx bx-money text-3xl text-success'></i>
                                        <span class="label-text font-semibold">Cash</span>
                                    </div>
                                    <input type="radio" wire:model="metode_pembayaran" value="cash" class="radio radio-success" checked />
                                </label>
                                <label class="label cursor-pointer border-2 rounded-lg p-4 has-[:checked]:border-warning has-[:checked]:bg-warning/10">
                                    <div class="flex flex-col items-center gap-2 flex-1">
                                        <i class='bx bx-qr text-3xl text-warning'></i>
                                        <span class="label-text font-semibold">QRIS</span>
                                    </div>
                                    <input type="radio" wire:model="metode_pembayaran" value="qris" class="radio radio-warning" />
                                </label>
                            </div>
                            @error('metode_pembayaran') <span class="text-error text-sm">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-control">
                            <label class="label">
                                <span class="label-text font-semibold">Pilih Tarif</span>
                            </label>
                            <select wire:model="tarif_id" class="select select-bordered w-full">
                                <option value="">-- Pilih Tarif --</option>
                                @foreach($tarifs as $tarif)
                                    <option value="{{ $tarif->id }}">{{ $tarif->tipe_ps }} - {{ $tarif->jenis_tarif }} (Rp {{ number_format($tarif->harga_per_jam, 0, ',', '.') }}/jam)</option>
                                @endforeach
                            </select>
                            @error('tarif_id') <span class="text-error text-sm">{{ $message }}</span> @enderror
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <div class="form-control">
                                <label class="label">
                                    <span class="label-text font-semibold">Durasi (Jam)</span>
                                </label>
                                <input type="number" wire:model="durasi_jam" class="input input-bordered" min="1" placeholder="Contoh: 5">
                                @error('durasi_jam') <span class="text-error text-sm">{{ $message }}</span> @enderror
                            </div>

                            <div class="form-control">
                                <label class="label">
                                    <span class="label-text font-semibold">Masa Berlaku (Hari)</span>
                                </label>
                                <input type="number" wire:model="expired_days" class="input input-bordered" min="1" max="365" placeholder="Contoh: 30">
                                @error('expired_days') <span class="text-error text-sm">{{ $message }}</span> @enderror
                            </div>
                        </div>

                        <div class="alert alert-success">
                            <i class='bx bx-info-circle text-xl'></i>
                            <div class="text-sm">
                                <p class="font-semibold">Kode voucher akan digenerate otomatis</p>
                                @if($metode_pembayaran === 'cash')
                                    <p class="text-xs mt-1">✓ Status: AKTIF & LUNAS (Cash)</p>
                                @else
                                    <p class="text-xs mt-1">⚠️ Status: PENDING (Menunggu bukti pembayaran QRIS)</p>
                                @endif
                            </div>
                        </div>
                    </div>

                    <div class="modal-action">
                        <button type="button" wire:click="closeModal" class="btn btn-ghost btn-md gap-2 px-6">
                            <i class='bx bx-x text-xl'></i>
                            Batal
                        </button>
                        <button type="submit" class="btn btn-primary btn-md gap-2 px-8 bg-gradient-to-r from-purple-600 to-pink-600 border-0">
                            <i class='bx bx-save text-xl'></i>
                            <span class="font-semibold">Simpan Voucher</span>
                        </button>
                    </div>
                </form>
            </div>
            <div class="modal-backdrop" wire:click="closeModal"></div>
        </div>
    @endif

    <!-- Delete Confirmation Modal -->
    @if($confirmingDelete)
        <div class="modal modal-open">
            <div class="modal-box">
                <h3 class="font-bold text-lg text-error mb-4">
                    <i class='bx bx-trash'></i>
                    Hapus Voucher
                </h3>
                <p class="py-4">Yakin ingin hapus voucher ini? Tindakan ini tidak dapat dibatalkan.</p>
                <div class="modal-action">
                    <button wire:click="cancelConfirmation" class="btn btn-ghost">Batal</button>
                    <button wire:click="executeDelete" class="btn btn-error">
                        <i class='bx bx-trash'></i>
                        Hapus
                    </button>
                </div>
            </div>
            <div class="modal-backdrop" wire:click="cancelConfirmation"></div>
        </div>
    @endif

    <!-- Approve Confirmation Modal -->
    @if($confirmingApprove)
        <div class="modal modal-open">
            <div class="modal-box">
                <h3 class="font-bold text-lg text-success mb-4">
                    <i class='bx bx-check-circle'></i>
                    Konfirmasi Pembayaran
                </h3>
                <p class="py-4">Konfirmasi pembayaran QRIS ini? Voucher akan diaktifkan.</p>
                <div class="modal-action">
                    <button wire:click="cancelConfirmation" class="btn btn-ghost">Batal</button>
                    <button wire:click="executeApprove" class="btn btn-success">
                        <i class='bx bx-check'></i>
                        Approve
                    </button>
                </div>
            </div>
            <div class="modal-backdrop" wire:click="cancelConfirmation"></div>
        </div>
    @endif

    <!-- Reject Confirmation Modal -->
    @if($confirmingReject)
        <div class="modal modal-open">
            <div class="modal-box">
                <h3 class="font-bold text-lg text-error mb-4">
                    <i class='bx bx-x-circle'></i>
                    Tolak Pembayaran
                </h3>
                <p class="py-4">Batalkan dan hapus voucher ini? Tindakan ini tidak dapat dibatalkan.</p>
                <div class="modal-action">
                    <button wire:click="cancelConfirmation" class="btn btn-ghost">Batal</button>
                    <button wire:click="executeReject" class="btn btn-error">
                        <i class='bx bx-x'></i>
                        Tolak & Hapus
                    </button>
                </div>
            </div>
            <div class="modal-backdrop" wire:click="cancelConfirmation"></div>
        </div>
    @endif

    <!-- Image Modal -->
    @if($showImageModal)
        <div class="modal modal-open">
            <div class="modal-box max-w-4xl bg-base-100">
                <button wire:click="closeImageModal" class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">
                    <i class='bx bx-x text-2xl'></i>
                </button>
                <h3 class="font-bold text-lg mb-4">
                    <i class='bx bx-image'></i>
                    Bukti Pembayaran
                </h3>
                <div class="flex justify-center">
                    <img src="{{ asset('storage/' . $selectedImage) }}" 
                         alt="Bukti Pembayaran" 
                         class="max-w-full max-h-[70vh] object-contain rounded-lg border-2 border-base-300">
                </div>
                <div class="modal-action">
                    <a href="{{ asset('storage/' . $selectedImage) }}" 
                       target="_blank" 
                       class="btn btn-primary gap-2">
                        <i class='bx bx-download'></i>
                        Buka di Tab Baru
                    </a>
                    <button wire:click="closeImageModal" class="btn btn-ghost">Tutup</button>
                </div>
            </div>
            <div class="modal-backdrop" wire:click="closeImageModal"></div>
        </div>
    @endif

    <!-- QRIS Preview Modal -->
    @if($showQrisModal)
        <div class="modal modal-open">
            <div class="modal-box max-w-2xl">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-2">
                        <i class='bx bx-qr text-info text-3xl'></i>
                        <div>
                            <p class="text-xs text-base-content/60">Pembayaran QRIS</p>
                            <h3 class="font-bold text-xl">Scan untuk Validasi</h3>
                        </div>
                    </div>
                    <button wire:click="closeQrisModal" class="btn btn-sm btn-circle btn-ghost">
                        <i class='bx bx-x text-xl'></i>
                    </button>
                </div>

                <div class="grid md:grid-cols-2 gap-6">
                    <div class="flex flex-col items-center gap-4">
                        <div class="bg-white p-4 rounded-xl border border-base-200 shadow-lg">
                            @if($qrisData)
                                {!! \SimpleSoftwareIO\QrCode\Facades\QrCode::size(200)->generate($qrisData) !!}
                            @else
                                <div class="w-48 h-48 flex items-center justify-center bg-base-200 rounded-lg">
                                    <span class="loading loading-spinner loading-lg"></span>
                                </div>
                            @endif
                        </div>
                        <p class="text-xs text-base-content/60 text-center">
                            Scan QR untuk memastikan nominal sesuai. QR ini sama seperti yang dilihat member saat pembayaran.
                        </p>
                    </div>
                    <div class="space-y-4 text-sm">
                        <div class="bg-base-200 rounded-xl p-4">
                            <p class="text-xs text-base-content/70">Nominal Unik</p>
                            <p class="text-3xl font-bold text-warning mt-1">
                                @if($previewQrisNominal)
                                    Rp {{ number_format($previewQrisNominal, 0, ',', '.') }}
                                @else
                                    -
                                @endif
                            </p>
                            <p class="text-xs text-base-content/60 mt-2">Transfer wajib mengikuti nominal di atas agar proses verifikasi manual lebih mudah.</p>
                        </div>
                        <div class="alert alert-info text-xs">
                            <i class='bx bx-info-circle'></i>
                            <span>Setelah menerima pembayaran, klik Approve untuk mengaktifkan voucher.</span>
                        </div>
                    </div>
                </div>

                <div class="modal-action">
                    <button type="button" class="btn btn-primary" wire:click="closeQrisModal">
                        Tutup
                    </button>
                </div>
            </div>
            <div class="modal-backdrop" wire:click="closeQrisModal"></div>
        </div>
    @endif
</div>
