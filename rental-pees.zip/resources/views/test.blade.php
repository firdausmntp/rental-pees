@extends('layout')

@section('content')
    <livewire:test-component />
@endsection
