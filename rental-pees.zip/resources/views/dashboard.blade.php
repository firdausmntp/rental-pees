<x-app-layout>
    <x-slot name="header">
        <h1 class="text-2xl font-semibold text-base-content">{{ __('Dasbor') }}</h1>
    </x-slot>

    <livewire:dashboard />
</x-app-layout>
