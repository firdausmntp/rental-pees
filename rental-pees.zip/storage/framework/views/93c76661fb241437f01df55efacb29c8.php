<div class="min-h-screen bg-base-200 p-4 md:p-6">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <h1 class="text-3xl font-bold flex items-center gap-2">
                <i class='bx bx-pause-circle text-4xl text-primary'></i>
                Kompromi Waktu Main
            </h1>
            <p class="text-base-content/70">Stop sesi berjalan dan buat voucher sisa waktu otomatis.</p>
        </div>
    </div>

    <!--[if BLOCK]><![endif]--><?php if($successMessage): ?>
        <div class="alert alert-success shadow mb-4">
            <i class='bx bx-check-circle'></i>
            <span><?php echo e($successMessage); ?></span>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($errorMessage): ?>
        <div class="alert alert-error shadow mb-4">
            <i class='bx bx-x-circle'></i>
            <span><?php echo e($errorMessage); ?></span>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <div class="card bg-base-100 shadow-xl">
        <div class="card-body">
            <div class="overflow-x-auto">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Transaksi</th>
                            <th>PS</th>
                            <th>Mulai</th>
                            <th>Durasi Awal</th>
                            <th>Berjalan</th>
                            <th>Sisa</th>
                            <th>Voucher (menit)</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $waktuMulai = \Carbon\Carbon::parse($trx->waktu_mulai);
                                $waktuSelesai = \Carbon\Carbon::parse($trx->waktu_selesai);
                                $startUnix = $waktuMulai->timestamp * 1000; // Convert to milliseconds
                                $endUnix = $waktuSelesai->timestamp * 1000; // Convert to milliseconds
                                // Calculate ACTUAL duration from waktu_selesai - waktu_mulai
                                $totalMinutes = (int) $waktuMulai->diffInMinutes($waktuSelesai);
                                $durasiDisplay = $totalMinutes >= 60 
                                    ? floor($totalMinutes / 60) . ' jam ' . ($totalMinutes % 60 > 0 ? ($totalMinutes % 60) . ' menit' : '')
                                    : $totalMinutes . ' menit';
                            ?>
                            <tr x-data="transactionTimer(<?php echo e($startUnix); ?>, <?php echo e($endUnix); ?>, <?php echo e($totalMinutes); ?>)">>
                                <td>
                                    <div class="font-semibold"><?php echo e($trx->kode_transaksi); ?></div>
                                    <div class="text-xs text-base-content/60"><?php echo e($trx->pelanggan->nama ?? 'Walk-in'); ?></div>
                                </td>
                                <td><?php echo e($trx->playStation->nama_konsol ?? $trx->playStation->tipe); ?></td>
                                <td><?php echo e($waktuMulai->format('d M Y H:i')); ?></td>
                                <td><?php echo e($durasiDisplay); ?></td>
                                <td>
                                    <span x-text="elapsedMinutes"></span> menit
                                </td>
                                <td>
                                    <span x-text="remainingMinutes"></span> menit (≈ <span x-text="remainingHours"></span> jam)
                                </td>
                                <td>
                                    <div class="space-y-2" x-data="{ minutes: <?php echo json_encode(isset($customMinutes[$trx->id]) && $customMinutes[$trx->id] > 0 ? (int) $customMinutes[$trx->id] : null, 15, 512) ?> }">
                                        <div class="font-semibold text-lg">
                                            <span x-text="minutes !== null ? minutes : remainingMinutes"></span>
                                            <span>menit</span>
                                        </div>
                                        <input type="number" min="1" 
                                            wire:model.live="customMinutes.<?php echo e($trx->id); ?>" 
                                            @input="minutes = parseInt($event.target.value) || null"
                                            :placeholder="remainingMinutes" 
                                            class="input input-bordered input-sm w-20 font-semibold text-center mt-1" />
                                        <div class="text-xs text-base-content/50">
                                            (sisa: <span x-text="remainingMinutes"></span> menit)
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <button wire:click="stopAndGenerateVoucher(<?php echo e($trx->id); ?>)" class="btn btn-primary btn-sm gap-2">
                                        <i class='bx bx-stop-circle text-lg'></i>
                                        Stop & Buat
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-base-content/60 py-6">Tidak ada transaksi berjalan</td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function transactionTimer(startUnix, endUnix, totalMinutes) {
            return {
                elapsedMinutes: 0,
                remainingMinutes: totalMinutes,
                remainingHours: Math.max(1, Math.ceil(totalMinutes / 60)),
                
                init() {
                    this.updateTimer();
                    setInterval(() => this.updateTimer(), 1000);
                },
                
                updateTimer() {
                    const now = Date.now();
                    // Calculate remaining from endUnix (waktu_selesai)
                    const remainingMs = endUnix - now;
                    this.remainingMinutes = Math.max(0, Math.ceil(remainingMs / 1000 / 60));
                    this.elapsedMinutes = totalMinutes - this.remainingMinutes;
                    this.remainingHours = Math.max(1, Math.ceil(this.remainingMinutes / 60));
                }
            }
        }
    </script>
</div>
<?php /**PATH C:\laragon\www\rental-pees\resources\views/livewire/kompromi.blade.php ENDPATH**/ ?>